from setuptools import setup

setup(name='guitar_training',
      version='0.1',
      description='For guitar training',
      url='http://github.com/aaronengland/guitar_training',
      author='Aaron England',
      author_email='aaron.england24@gmail.com',
      license='MIT',
      packages=['guitar_training'],
      zip_safe=False)